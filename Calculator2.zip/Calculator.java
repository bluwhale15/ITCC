/**
  * Michael Laguardia ICC 11 A
  * JAVA CALCULATOR
  */
  
 import javax.swing.*;
 import java.awt.*;
 
 
 class Calculator{
 
     private JFrame firstframe;
	 private JTextField display;
	 private JPanel firstpanel;
	 private JPanel buttonPanel;
	 private GridLayout grid;
	 private BorderLayout firstlayout;
	 
	 
	 
	 private JButton B1;
	 private JButton B2;
	 private JButton B3;
	 private JButton B4;
	 private JButton B5;
	 private JButton B6;
	 private JButton B7;
	 private JButton B8;
	 private JButton B9;
	 private JButton B0;
	 private JButton period;
	 private JButton addition;
	 private JButton subtraction;
	 private JButton multiplication;
	 private JButton division;
	 private JButton equal;
	 private JButton clear;
	 
	 
	 public Calculator(){
	 
	   firstframe      = new JFrame("calculator");
	   firstframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   
	   display        = new JTextField("0");
	   firstlayout    = new BorderLayout();
	   grid           = new GridLayout(4,4);
	   
	   
	   firstpanel     = new JPanel(firstlayout);
	   buttonPanel    = new JPanel(grid);
	   
	   B1             = new JButton("1"); 
	   B2             = new JButton("2"); 
	   B3             = new JButton("3"); 
	   B4             = new JButton("4"); 
	   B5             = new JButton("5"); 
	   B6             = new JButton("6"); 
	   B7             = new JButton("7"); 
	   B8             = new JButton("8"); 
	   B9             = new JButton("9"); 
	   B0             = new JButton("0");	   
	   addition       = new JButton("+"); 
	   subtraction    = new JButton("-"); 
	   multiplication = new JButton("*"); 
	   division       = new JButton("/");
       clear          = new JButton("C"); 
       equal          = new JButton("=");	   

       buttonPanel.add(B7);
	   buttonPanel.add(B8);
	   buttonPanel.add(B9);
	   buttonPanel.add(addition);
	   
	   buttonPanel.add(B4);
	   buttonPanel.add(B5);
	   buttonPanel.add(B6);
	   buttonPanel.add(subtraction);
	   
	   buttonPanel.add(B1);
	   buttonPanel.add(B2);
	   buttonPanel.add(B3);
	   buttonPanel.add(multiplication);
	   
	   buttonPanel.add(B0);
	   buttonPanel.add(clear);
	   buttonPanel.add(equal);
	   buttonPanel.add(division);
	   
	   
	   
	   
	   
	   firstpanel.add(display, BorderLayout.PAGE_START);
	   firstpanel.add(buttonPanel, BorderLayout.CENTER);
	   firstframe.add(firstpanel);
	   
	   firstframe.pack();
	   
	   firstframe.setResizable(false);
	   firstframe.setVisible(true);
	   
	   
	 }
	   
	 }