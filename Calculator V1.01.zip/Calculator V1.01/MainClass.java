/**
  *Michael Laguardia ITCC11 A
  *October 5 2020
  */
public class MainClass {
   public static void main(String[] args){
     Calculator c = new Calculator();
   }
}