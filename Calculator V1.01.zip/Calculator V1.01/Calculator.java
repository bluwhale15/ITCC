/**
  *Michael Laguardia ITCC11 A
  *October 5 2020
  */
  
  import javax.swing.*;
  import java.awt.*;
  import java.awt.event.*;
 
  class Calculator {
	
	  private JFrame frame;
	  private JTextField text;
	 
	  private JPanel mainPanel;
	  private JPanel buttonPanel;
	  
	  //Buttons//
	  private JButton one;
	  private JButton two;
	  private JButton three;
	  private JButton four;
	  private JButton five;
	  private JButton six;
	  private JButton seven;
	  private JButton eight;
	  private JButton nine;
	  private JButton zero;
	  private JButton period;
	  
	  private JButton clear;
	  
	  
	  private JButton addition;	
	  private JButton subtraction;
	  private JButton multiplication;
	  private JButton division;
	  private JButton equals;
	  
	  // buttons end //
	  
	  private GridLayout grid;
	  private BorderLayout mainLayout;
	  
	  private ActionListener buttonActionListener;
	  private ActionListener plusActionListener;
	  private ActionListener subtractionActionListener;
	  private ActionListener timesActionListener;
	  private ActionListener divideActionListener;
	  
	  private ActionListener clActionListener;	  

	  private ActionListener equalsActionListener;
	  
	  char operator;
	  double num1=0, num2=0, answer=0;
	  
	  
	  
	  public Calculator(){
		  frame = new JFrame("Calculator");
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  
		  mainLayout = new BorderLayout();
		  grid       = new GridLayout(5,4);
		 
		  text       = new JTextField(20);
		  text.setHorizontalAlignment(JTextField.RIGHT);
		  
		  mainPanel   = new JPanel(mainLayout);
		  buttonPanel =	new JPanel(grid);	  
		  
		  buttonActionListener                       = new MyActionListener();
		  plusActionListener                         = new PlusActionListener();
		  subtractionActionListener                  = new MinusActionListener();
		  timesActionListener                        = new MultiplyActionListener();
		  divideActionListener                       = new DivideActionListener();
		  
		  clActionListener          = new ClearActionListener();
		  
		  equalsActionListener      = new answerActionListener();
		  
		  one            = new JButton("1");
		  one.addActionListener(buttonActionListener);
		  
		  two            = new JButton("2");
		  two.addActionListener(buttonActionListener);
		   
		  three          = new JButton("3");
		  three.addActionListener(buttonActionListener);
		  
		  four           = new JButton("4");
		  four.addActionListener(buttonActionListener);
		  
		  five           = new JButton("5");
		  five.addActionListener(buttonActionListener);
		  
		  six            = new JButton("6");
		  six.addActionListener(buttonActionListener);
		  
		  seven          = new JButton("7");
		  seven.addActionListener(buttonActionListener);
		  
		  eight          = new JButton("8");
		  eight.addActionListener(buttonActionListener);
		  
		  nine           = new JButton("9");
		  nine.addActionListener(buttonActionListener);
		  
		  zero           = new JButton("0");
		  zero.addActionListener(buttonActionListener); 
		  
		  period         = new JButton(".");
		  period.addActionListener(buttonActionListener);
		  
		  clear          = new JButton("C");
		  clear.addActionListener(clActionListener);
		  
		  addition       = new JButton("+");		  
		  addition.addActionListener(plusActionListener);
		  
		  subtraction    = new JButton("-");
		  subtraction.addActionListener(subtractionActionListener);
		  
		  multiplication = new JButton("*");
		  multiplication.addActionListener(timesActionListener);
		  
		  division       = new JButton("/");
		  division.addActionListener(divideActionListener);
		  
		  equals         = new JButton("=");
		  equals.addActionListener(equalsActionListener);
		  		  
		  
		  buttonPanel.add(addition);
		  		  
		  buttonPanel.add(seven);
		  buttonPanel.add(eight);
		  buttonPanel.add(nine);
		  buttonPanel.add(subtraction);
		  
		  buttonPanel.add(four);
		  buttonPanel.add(five);
		  buttonPanel.add(six);
		  buttonPanel.add(multiplication);
		  
		  buttonPanel.add(one);
		  buttonPanel.add(two);
		  buttonPanel.add(three);
		  buttonPanel.add(division);
		  
		  buttonPanel.add(zero);
		  buttonPanel.add(period);
		  buttonPanel.add(clear);
		  buttonPanel.add(equals);
		  
		  
		  
		  mainPanel.add(text, BorderLayout.PAGE_START);
		  mainPanel.add(buttonPanel, BorderLayout.CENTER);
		  frame.add(mainPanel);
		  
		  frame.pack();
		  
		  frame.setResizable(false);
		  frame.setVisible(true);
		 
	  }
	  class ClearActionListener implements ActionListener{
		  
		  public void actionPerformed(ActionEvent event) {
			  
			  if (event.getActionCommand()== "C") {
				  text.setText("");
			  }
			  else{
				  
				  String tmpStr = text.getText();
				  tmpStr = tmpStr + event.getActionCommand();
				  text.setText(tmpStr);
  
			  }
		  }
	  }  
	  

	  
	  
	  class PlusActionListener implements ActionListener{
		
		public void actionPerformed(ActionEvent event){
			
			num1 = Double.parseDouble(text.getText());
			operator ='+';
			text.setText("");
		}
	  }
		
	  class MinusActionListener implements ActionListener{
		
		public void actionPerformed(ActionEvent event){
			
			num1 = Double.parseDouble(text.getText());
			operator ='-';
			text.setText("");
		}
	  }
		
	  class MultiplyActionListener implements ActionListener{
		
		public void actionPerformed(ActionEvent event){
			
			num1 = Double.parseDouble(text.getText());
			operator ='*';
			text.setText("");
		}
	  }

	  class DivideActionListener implements ActionListener{
		
		public void actionPerformed(ActionEvent event){
			
			num1 = Double.parseDouble(text.getText());
			operator ='/';
			text.setText("");
		}
	  }
	
	  class answerActionListener implements ActionListener{
		
		public void actionPerformed(ActionEvent event){
			
			num2=Double.parseDouble(text.getText());
			// algorithm for the different operations //
			switch(operator) {
			case'+':
				answer=num1+num2;
				break;
			case'-':
				answer=num1-num2;
				break;
			case'*':
				answer=num1*num2;
				break;
			case'/':
				answer=num1/num2;
				break;
			}
			text.setText(String.valueOf(answer));
			num1=answer;
		}
	  
	  }
	  
  }
  
  
  
  
 
	


