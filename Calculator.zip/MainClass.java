import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
public class MainClass {
   public static void main(String[] args){
      calculator c = new calculator();
	 	  
   }
}