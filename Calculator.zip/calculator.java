/**
  * Michael Laguardia, ITCC A
  * October 5, 2020
  */
  
  import java.awt.*;
  import javax.swing.*;
  
  class calculator extends JFrame {
	  
	  JTextField t1;
	  JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,equal,addidtion,subtraction,multiplication,divide,clear;
  
	calculator() {
		setSize(600,500);
		setTitle("My Calculator");
		setLocationRelativeTo(null);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		t1=new JTextField(50);
		t1.setBounds(10,10,730,50);
		add(t1);
		t1.setEditable(false);
		
		b1=new JButton("1");
		b2=new JButton("2");
		b3=new JButton("3");
		b4=new JButton("4");
		b5=new JButton("5");
		b6=new JButton("6");
		b7=new JButton("7");
		b8=new JButton("8");
		b9=new JButton("9");
		b10=new JButton("0");
		b11=new JButton(".");
		b12=new JButton("00");
		equal=new JButton("=");
		clear=new JButton("clear");
		addidtion= new JButton("+");
		subtraction=new JButton("-");
		multiplication=new JButton("*");
		divide=new JButton("/");
		
		b1.setBounds(10,80,70,60);
		b2.setBounds(120,80,70,60);
		b3.setBounds(230,80,70,60);
		b4.setBounds(10,170,70,60);
		b5.setBounds(120,170,70,60);
		b6.setBounds(230,170,70,60);
		b7.setBounds(10,260,70,60);
		b8.setBounds(120,260,70,60);
		b9.setBounds(230,260,70,60);
		b10.setBounds(10,350,70,60);
		b11.setBounds(230,350,70,60);
		b12.setBounds(120,350,70,60);
		equal.setBounds(350,350,170,60);
		clear.setBounds(350,80,177,60);
		addidtion.setBounds(350,260,70,60);
		subtraction.setBounds(460,260,70,60);
		multiplication.setBounds(350,170,70,60);
		divide.setBounds(460,170,70,60);
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(b6);
		add(b7);
		add(b8);
		add(b9);	
		add(b10);
		add(b11);
		add(b12);
		add(equal);
		add(clear);
		add(addidtion);
		add(subtraction);
		add(multiplication);
		add(divide);
		
		setVisible(true);
	}	
  public static void main(String[] args){
	  
	  new calculator();
	 
	}
  }
  
  
  
  

  
	